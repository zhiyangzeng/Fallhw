public class MyClass {
	public MyClass() {}
	public static boolean testTrue(){ return true; }
	public static boolean testFalse() {return false; }
	public static boolean testX() {return false;}
	public static boolean test() {return true;}
	public boolean testY() {return true;};
	private static boolean testZ() {return true;}
	public static double testD(){return 4.0;}
}