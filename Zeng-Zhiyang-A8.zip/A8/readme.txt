Dear grader:

To compile: javac *.java

To run problem 1: java Main1
(programs associated: Main1.java, PostBox.java)

To run problem 2: java Main2
(programs associated: Main2.java, printTime.java)

To run problem 3: java Main3
(programs associated: Main3.java. 
 Tested class: LinkedList.java, Node.java, NodeIterator.java, MyClass.java. 
 Class A inside Main3)

To run problem 4: java Main4 MyClass
(programs associated: Main4.java. Tested class: MyClass)

Thank you and happy grading :)